______ _____  ___ _________  ___ _____ 
| ___ \  ___|/ _ \|  _  \  \/  ||  ___|
| |_/ / |__ / /_\ \ | | | .  . || |__  
|    /|  __||  _  | | | | |\/| ||  __| 
| |\ \| |___| | | | |/ /| |  | || |___ 
\_| \_\____/\_| |_/___/ \_|  |_/\____/ 
                                       

1. Open the index.html file in any WebGL Compliant Browser (Chrome/Firefox/Safari/Opera)
2. Place your phone in the google cardboard. In case you don’t have one, use the left and right arrow keys to navigate.

3. Project Website is at http://52.8.85.134/cs580site/index.html