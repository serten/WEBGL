var specularCoefficient = [ 0.3, 0.3, 0.3 ];
var ambientCoefficient = [ 0.1, 0.1, 0.1 ];
var diffuseCoefficient = [ 0.7, 0.7, 0.7 ];
var shininess = 32.0;