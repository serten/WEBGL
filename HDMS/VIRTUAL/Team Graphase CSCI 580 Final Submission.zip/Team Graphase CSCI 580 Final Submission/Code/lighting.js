var lighting = {
	"numlights" : 1,
	"lights": [
		{
			"direction": [-0.7071, 0.7071, 0],
			"color": [0.5, 0.5, 0.9]
		}
	],
	"ambient": {
		"color": [0.3, 0.3, 0.3]
	}
};